from lib import display, userinput
from lib.hydra import config, beeper
# from lib.userinput import userinput
from font import vga2_16x32 as font2
from font import vga1_8x16 as font1
import machine, time, random, array
_DISPLAY_HEIGHT = const(135)
_DISPLAY_WIDTH = const(240)
_DISPLAY_WIDTH_HALF = const(_DISPLAY_WIDTH // 2)
_CHAR_WIDTH = const(8)
_CHAR_WIDTH_HALF = const(_CHAR_WIDTH // 2)
tft =  display.Display()
# tft = st7789.ST7789(
#     machine.SPI(
#         1,baudrate=40000000,sck=machine.Pin(36),mosi=machine.Pin(35),miso=None),
#     _DISPLAY_HEIGHT,
#     _DISPLAY_WIDTH,
#     reset=machine.Pin(33, machine.Pin.OUT),
#     cs=machine.Pin(37, machine.Pin.OUT),
#     dc=machine.Pin(34, machine.Pin.OUT),
#     backlight=machine.Pin(38, machine.Pin.OUT),
#     rotation=1,
# #     color_order=st7789.BGR
#     )
beep = beeper.Beeper()
config = config.Config()
kb = userinput.UserInput()
sPos = 0
ballExited = False
Counter = 0
p1POINTS = 0
p2POINTS = 0
specialVal = 'none'
bordY = 47 # y board location 
flag2 = True 
bordY2 = 47 # second y board location (2pMode)
current_key = "none" # key for 
current_key2p = "none"
direction = 0 # ball direction
select = 1 # menu option select
step = 5 # speed of board movement
startFlag = True
addFlag = True
popFlag = False
crrent_key = 'none'
clearMod1 = True
clearMod2 = True
clearMod3 = True
listenKB = True
ModM1 = True
specialKeys = 'none'
ModM2 = True
ModM3 = True
altMenu = False
altMenuSelect = 1
command = 'o'
command2 = 'o'
command2p = 'o'
ballStepX = 2
timer = 0
ballStepY = 2
mode = 'menu' # mode, can be menu, 1 player or 2 players
Mcommands = ["['/']","[',']","[';']","['.']","['ENT']"]
p1commands = ["[';']","['.']","['`']"]
p2commands = ["[';']","['.']","['`']"]
p2p2commands = ["['ALT']","['a']","['`']"]
specialCommands = [[';'],['.'],['ENT']]
blL = True
blR = False
blU = False
blD = True
ballColor = 65535
yBstep = -1
xBstep = -1
touch = 'none'
ballX = 115
ballY = 65
def touched(Character_widht, Character_height, Block_widht, Block_height, Block_x, Block_y, Character_x, Character_y, Character_step, parametr):
        global touch
        if Character_x == Block_x + Block_widht and Character_y > Block_y - Character_height + 1 and Character_y < Block_y + Block_height -1:
            touch = parametr
        if Character_x == Block_x + 1 - Character_widht and Character_y > Block_y - Character_height + 1 and Character_y < Block_y + Block_height -1:
            Character_x -= Character_step
            touch = parametr
        if Character_y == Block_y + 1 - Character_height and Character_x > Block_x - Character_widht + 1 and Character_x < Block_x + Block_widht -1:
            Character_y -= Character_step
            touch = parametr
        if Character_y == Block_y - 1 + Block_height  and Character_x > Block_x - Character_widht + 1 and Character_x < Block_x + Block_widht -1:
            Character_y += Character_step
            touch = parametr
            return touch
# def mvByDirection(x,y,directionValue,mapBorderY,mapBorderX):
# #     def directionReverse(directionValue):
# #         if directionValue == 1:
# #             directionValue = 2
# #         if directionValue == 2:
# #             directionValue = 2
#     if directionValue == 1:
#         if x <= mapBorderX:
#             x += 1
#             else:
#                 directionValue = 2
#         if y <= mapBorderY:
#             y += 1
#     if directionValue == 2:      
#         x += 1
#         y -= 1
while True:
#     print(str(listenKB))
#     print(command)
#     keys = kb.get_pressed_keys()
#     if keys:
#         current_key = str(keys)
#     print(str(current_key))
#     print(str(specialKeys))
#     touched(10,10,240,1,0,0,ballX,ballY,1,'UpBoarder')
#     touched(10,10,240,1,0,134,ballX,ballY,1,'DownBoarder')
#     touched(10,10,7,40,220,bordY2,ballX,ballY,1,'LeftBoarder')
#     touched(10,10,7,40,20,bordY,ballX,ballY,1,'RightBoarder')
    if mode == 'menu':
        if listenKB:
            keys = kb.get_new_keys()
            if keys:
                current_key = str(keys)
            if current_key in Mcommands:
                command = current_key
        listenKB = True
        if clearMod1:
            tft.fill(000)
            clearMod1 = False
            clearMod2 = True
            clearMod3 = True 
        tft._bitmap_text(font2, '1P' ,45 ,50 ,65535)
        tft._bitmap_text(font2, '2P' ,165 ,50,65535)
        tft.show()
        if command == "[',']":
            select = 1
            tft.rect(120,0,120,135,000,)
        if command == "['/']":
            select = 2
            tft.rect(0,0,120,135,000)
        if select == 1:
            sPos = 0
            if command == "['ENT']":
                mode = '1pGame'
        if select == 2:
            sPos = 120
            if command == "['ENT']":
                mode = '2pGame'
        tft.rect(sPos,0,120,135,65535)
        tft.show()
    if mode == '1pGame':
#         print(str(command))
        keys = kb.get_pressed_keys()
        print('wwwwwwwww')
        print(keys)
        if keys:
            current_key = str(keys)
        if current_key in p1commands:
            command = keys
        if clearMod2:
            tft.fill(000)
            tft.show()
            clearMod2 = False
            clearMod1 = True
            clearMod3 = True 
        tft.fill_rect(10,bordY,7,40,65535)
        tft.fill_rect(120,0,1,135,65535)
        tft.fill_rect(10,bordY + 40,7,10,000)
        tft.fill_rect(10,bordY - 10,7,10,000)
        tft.show()
        if command == ['`']:
            mode = 'menu'
        if command == [';'] and bordY >= 0:
            bordY -= step
        if command == ['.'] and bordY <= 95:
            bordY += step
    if mode == '2pGame':
        Counter += 1
        if Counter >= 300:
            timer = 3
        if altMenu == False :
            tft.fill(000)
        if ballX > 240:
            p1POINTS += 1
            ballX = 115
            ballY = 65
            touch = 'RightBoarder'
            ballExited = True
        if ballX <= -10:
            p2POINTS += 1
            ballX = 115
            ballY = 65
            touch = 'LeftBoarder'
            ballExited = True
#             tft.text(str(p1POINTS),125,10)
#             tft.show()
        if ballY >= 124:
            touch = 'DownBoarder'
        if ballY <= 11:
            touch = 'UpBoarder'
        if ballX <= 17 and ballX >= 10 and ballY >= bordY and ballY <= bordY + 40:
            touch = 'LeftBoarder'
        if ballX >= 210 and ballX <= 227 and ballY >= bordY2 and ballY <= bordY2 + 40:
            touch = 'RightBoarder'
        if ballX >= 210 and ballX <= 227 and ballY == bordY2 + 40:
            touch = 'RightBoarder'
        ballY += yBstep
        ballX += xBstep
#         print(str(command))
        keys = kb.get_pressed_keys()
        if keys:
            current_key = str(keys)
            current_key2p = str(keys)
        if current_key in p2commands:
            command = current_key
        if current_key2p in p2p2commands:
            command2 = current_key2p
        if clearMod3:
            tft.fill(000)
            tft.show()
            clearMod3 = False
            clearMod1 = True
            clearMod2 = True 
        tft.fill_rect(10,bordY,7,40,65535)
        tft.fill_rect(220,bordY2,7,40,65535)
        tft.fill_rect(ballX,ballY,10,10,ballColor)
        tft.fill_rect(0,0,240,1,65535)
        tft.fill_rect(0,134,240,1,65535)
        tft.text(str(p2POINTS),130,10,65535)
        tft.text(str(p1POINTS),100,10,65535)
        if altMenu == False:
            tft.fill_rect(120,1,1,134,65535)
        if touch == 'UpBoarder':
            blU = True
            blD = False
        if touch == 'DownBoarder':
            blD = True
            blU = False
        if touch == 'RightBoarder':
            blL = True
            blR = False
        if touch == 'LeftBoarder':
            blR = True
            blL = False
        if blU == True:
#             tft.fill_rect( ballX,ballY - 10,11,11,000)
            yBstep = ballStepY
            if altMenu == False:
                time.sleep_ms(timer)
        if blD == True:
#             tft.fill_rect( ballX,ballY + 10,11,11,000)
            yBstep = -ballStepY
            if altMenu == False:
                time.sleep_ms(timer)
        if blL == True:
#             tft.fill_rect( ballX + 10,ballY,11,11,000)
            xBstep = -ballStepX
            if altMenu == False:
                time.sleep_ms(timer)
        if blR == True:
#             tft.fill_rect( ballX - 10,ballY,11,11,000)
            xBstep = ballStepX
            if altMenu == False:
                time.sleep_ms(timer)
        tft.show()
        if ballExited == True:
            time.sleep_ms(200)
            ballColor = 65535
            tft.fill_rect(ballX,ballY,10,10,ballColor)
            tft.show()
            time.sleep_ms(200)
            ballColor = 0
            tft.fill_rect(ballX,ballY,10,10,ballColor)
            tft.show()
            time.sleep_ms(200)
            ballColor = 65535
            tft.fill_rect(ballX,ballY,10,10,ballColor)
            tft.show()
            time.sleep_ms(200)
            ballColor = 0
            tft.fill_rect(ballX,ballY,10,10,ballColor)
            tft.show()
            time.sleep_ms(200)
            ballColor = 65535
            tft.fill_rect(ballX,ballY,10,10,ballColor)
            tft.show()
            time.sleep_ms(200)
            ballColor = 0
            tft.fill_rect(ballX,ballY,10,10,ballColor)
            tft.show()
            time.sleep_ms(200)
            ballColor = 65535
            tft.fill_rect(ballX,ballY,10,10,ballColor)
            tft.show()
            ballExited = False
        if altMenu == False:
            ballStepY = 2
            ballStepX = 2
            ballColor = 65535
            timer = 4
            step = 2
            if "['ENT']" in p2commands:
                p2commands.remove("['ENT']")
            if popFlag:
                tft.fill_rect(60,20,120,95,000)
                tft.show()
                popFlag = False
                
            addFlag = True
        if command == "['`']":
            altMenu = True
#             mode = 'menu'
#             tft.rect(60,20,120,115,65535)
#             tff.show()
        if command == "[';']" and bordY2 >= 0:
            tft.fill_rect(220,bordY2 + 40,7,10,000)
            bordY2 -= step
        if command == "['.']" and bordY2 <= 95:
            tft.fill_rect(220,bordY2 - 10,7,10,000)
            bordY2 += step
        if command2 == "['a']" and bordY >= 0:
            tft.fill_rect(10,bordY + 40,7,10,000)
            bordY -= step
        if command2 == "['ALT']" and bordY <= 95:
            tft.fill_rect(10,bordY - 10,7,10,000)
            bordY += step
    if altMenu:
        ballColor = 0
        timer = 1
        step = 0
        ballStepY = 0
        ballStepX = 0
        popFlag = True
        if addFlag:
            p2commands.append("['ENT']")
            addFlag = False 
        tft.rect(60,20,120,95,65535)
        tft.fill_rect(61,21,118,93,000)
        tft.text('settings',88,40, 65535)
        tft.text('resume',94,60, 65535)
        tft.text('menu',102,80, 65535)
        kys = kb.get_new_keys()
        if kys:
            crrent_key = str(kys)
        if crrent_key == "['.']":
            altMenuSelect += 1
            editMode = 'none'
            if altMenuSelect > 3:
                altMenuSelect = 1
            kys = ['none']
            crrent_key = '0'
        if crrent_key == "[';']":
            altMenuSelect -= 1
            if altMenuSelect < 1:
                altMenuSelect = 3
            kys = ['none']
            crrent_key = '0'
        if altMenuSelect == 1:
            tft.text('>',75,40, 65535)
            tft.text('<',156,40, 65535)
            tft.show()
        if altMenuSelect == 2:
            tft.text('>',81,60, 65535)
            tft.text('<',147,60, 65535)
            tft.show()
            if command == "['ENT']":
                altMenu = False
        if altMenuSelect == 3:
            tft.text('>',89,80, 65535)
            tft.text('<',138,80, 65535)
            if command == "['ENT']":
                mode = 'menu'
                altMenu = False
                listenKB = False
                current_key = 'none'
                command = 'none'
        tft.show()
        
        
        
        
        
        
        
        
        
        
        
#     if ballX == 115 and ballY == 65:
#             time.sleep_ms(200)
#             ballColor = 65535
#             time.sleep_ms(200)
#             ballColor = 0
#             time.sleep_ms(200)
#             ballColor = 65535
#             time.sleep_ms(200)
#             ballColor = 0
#             time.sleep_ms(200)
#             ballColor = 65535
#             time.sleep_ms(200)
#             ballColor = 0
#             time.sleep_ms(200)
#             ballColor = 65535
#         if altMenuSelect == 1:
#             tft.text('>',75,40)
#             tft.text('<',156,40)
#             tft.show()
#         if altMenuSelect == 2:
#             tft.text('>',81,60)
#             tft.text('<',147,60)
#             tft.show()
#         if altMenuSelect == 3:
#             tft.text('>',89,80)
#             tft.text('<',138,80)
#             tft.show()
        
    
    




    
